package se.lth.solid.vilmer

import android.graphics.Bitmap
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import se.lth.solid.vilmer.databinding.FragmentAddCardBinding


class AddCardFragment : Fragment() {

    private val listViewModel: ListViewModel by activityViewModels()
    private lateinit var viewBinding: FragmentAddCardBinding

    private lateinit var name: String
    private var image: Bitmap? = null
    private var tags: Array<String> = arrayOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
        (activity as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        viewBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_add_card, container, false)

        viewBinding.photoButton.setOnClickListener {
            findNavController().navigate(R.id.action_addCardFragment_to_photoFragment)
        }

        return viewBinding.root
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.add_card_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                activity?.onBackPressed()
                true
            }
            R.id.done -> {
                name = viewBinding.nameEditText.editText?.text.toString()
                listViewModel.addCard(image, name, tags)
                activity?.onBackPressed()
                true
            }
            else -> {
                false
            }
        }
    }
}